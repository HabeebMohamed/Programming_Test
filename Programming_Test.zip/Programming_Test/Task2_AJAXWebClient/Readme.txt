IMPORTANT NOTE:

The task at hand requires the use of PUT, POST and PATCH HTTP requests to the server and displaying the modified/newly created content on the web page without the need for reloading. 

The server side of the code has not been submitted. The client side implementation is simple
and the user would require to configure according to the server needs. No libraries have been used
and only browser APIs used. No backward compatibility checks/adaptation implemented. Callabcks have been avoided and only the onreadystatchange attribite of XHttpRequest is used to detect and display server responses.